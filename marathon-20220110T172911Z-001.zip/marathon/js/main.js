$(function(){
$('.header-slider').slick({
    arrows: false,
    vertical: true,
    dots: true,
    dotsClass: 'header-dots',
    autoplay: 1000,
    fade: true,
});

$('.menu-btm').on('click', function(){
    $('.menu_list').slideToggle();
});

});

